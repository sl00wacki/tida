import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.util.Date;
import java.util.Scanner;
import java.util.Stack;

class Person {
    private String imie;
    private String nazwisko;
    private Date dataUrodzenia;
    private String miejsceUrodzenia;
    private String email;
    private int telefon;

    public Person(String imie, String nazwisko, Date dataUrodzenia, String miejsceUrodzenia, String email, int telefon) {
        this.imie = imie;
        this.nazwisko = nazwisko;
        this.dataUrodzenia = dataUrodzenia;
        this.miejsceUrodzenia = miejsceUrodzenia;
        this.email = email;
        this.telefon = telefon;
    }

    public void setImie(String imie) {
        this.imie = imie;
    }

    public void setNazwisko(String nazwisko) {
        this.nazwisko = nazwisko;
    }

    public void setDataUrodzenia(Date dataUrodzenia) {
        this.dataUrodzenia = dataUrodzenia;
    }

    public void setMiejsceUrodzenia(String miejsceUrodzenia) {
        this.miejsceUrodzenia = miejsceUrodzenia;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public void setTelefon(int telefon) {
        this.telefon = telefon;
    }

    public PersonSnapshot createSnapshot() {
        return new PersonSnapshot(this.imie, this.nazwisko, this.dataUrodzenia, this.miejsceUrodzenia, this.email, this.telefon);
    }

    public void restore(PersonSnapshot snapshot) {
        this.imie = snapshot.getImie();
        this.nazwisko = snapshot.getNazwisko();
        this.dataUrodzenia = snapshot.getDataUrodzenia();
        this.miejsceUrodzenia = snapshot.getMiejsceUrodzenia();
        this.email = snapshot.getEmail();
        this.telefon = snapshot.getTelefon();
    }

    @Override
    public String toString() {
        return "Person\n" +
                "imie = " + imie +
                "\nnazwisko = " + nazwisko +
                "\ndataUrodzenia = " + dataUrodzenia +
                "\nmiejsceUrodzenia = " + miejsceUrodzenia +
                "\nemail = " + email+
                "\ntelefon = " + telefon;
    }
}

class PersonSnapshot {
    private String imie;
    private String nazwisko;
    private Date dataUrodzenia;
    private String miejsceUrodzenia;
    private String email;
    private int telefon;

    public PersonSnapshot(String imie, String nazwisko, Date dataUrodzenia, String miejsceUrodzenia, String email, int telefon) {
        this.imie = imie;
        this.nazwisko = nazwisko;
        this.dataUrodzenia = dataUrodzenia;
        this.miejsceUrodzenia = miejsceUrodzenia;
        this.email = email;
        this.telefon = telefon;
    }

    public String getImie() {
        return imie;
    }

    public String getNazwisko() {
        return nazwisko;
    }

    public Date getDataUrodzenia() {
        return dataUrodzenia;
    }

    public String getMiejsceUrodzenia() {
        return miejsceUrodzenia;
    }

    public String getEmail() {
        return email;
    }

    public int getTelefon() {
        return telefon;
    }
}

class Command {
    private Person person;
    private Stack<PersonSnapshot> backup = new Stack<>();

    public Command(Person person) {
        this.person = person;
    }

    public void makeBackup() {
        backup.push(person.createSnapshot());
    }

    public void undo() {
        if (!backup.isEmpty()) {
            person.restore(backup.pop());
        } else {
            System.out.println("Brak zapisanych stanów.");
        }
    }
}

public class Main {
    public static void main(String[] args) throws ParseException {
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
        Date dataUrodzenia = new Date(1990, 4, 1);
        Person person = new Person("Ania", "Gotuje", dataUrodzenia, "Warszawa", "kontakt@aniagotuje.pl.", 123456789);
        Command caretaker = new Command(person);
        Scanner scanner = new Scanner(System.in);
        System.out.println("Aktualny stan: " + person);
        caretaker.makeBackup();
        System.out.println("Wprowadz imie:");
        person.setImie(scanner.nextLine());
        System.out.println("Wprowadź nazwisko");
        person.setNazwisko(scanner.nextLine());
        System.out.println("Wprowadź date urodzenia");
        String dataUrodzeniaTemp = scanner.nextLine();
        Date dataUrodzeniaNew = dateFormat.parse(dataUrodzeniaTemp);
        person.setDataUrodzenia(dataUrodzeniaNew);
        System.out.println("Wprowadź miejsce urodzenia");
        person.setMiejsceUrodzenia(scanner.nextLine());
        System.out.println("Wprowadź telefon");
        person.setTelefon(scanner.nextInt());
        System.out.println("\nPo zmianie imienia: " + person);
        caretaker.undo();
        System.out.println("\n Po cofnięciu: " + person);
    }
}

