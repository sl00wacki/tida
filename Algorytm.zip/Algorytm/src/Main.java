import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;
import java.util.Random;


public class Main {
    public static void main(String[] args) throws IOException {
        int dlugosc=0, czyZapisac;
        Random rand = new Random();
        String CHARACTERS = "0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ";
        String CHARACTERSonlynumbers = "0123456789";
        System.out.println("Podaj długość kodu\n4 albo 6 - kod numeryczny \n12 lub 16 - kod z literami");
        Scanner scanner = new Scanner(System.in);
        dlugosc= scanner.nextInt();
        String kod = "", kodonlynumbers="";
        if(dlugosc==4 || dlugosc==6){
            for(int i=0;i<dlugosc;i++) {
                int index = rand.nextInt(CHARACTERSonlynumbers.length());
                kodonlynumbers += CHARACTERS.charAt(index);
            }
            System.out.println(kodonlynumbers);
        } else if(dlugosc==12 || dlugosc ==16){
            for(int i=0;i<dlugosc;i++){
                int index = rand.nextInt(CHARACTERS.length());
                kod += CHARACTERS.charAt(index);
            }
            System.out.println(kod);
        } else {
            System.out.println("Wprowadzono błędną długość");
        }
        System.out.println("Zapisać do pliku? \n 1 - tak, 2 - nie");
        czyZapisac=scanner.nextInt();
        if(czyZapisac==1){
            FileWriter zapis = new FileWriter("src/kod.txt");
            if(dlugosc==4 || dlugosc==6){
                zapis.write(kodonlynumbers);
                zapis.close();
            }
            if(dlugosc==12 || dlugosc==16){
                zapis.write(kod);
                zapis.close();
            }
        }
    }
}